package com.hexamc.economy;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

/** Read-only listing menu plus an explicit confirmation screen for purchases. */
final class AuctionGui implements Listener {
    private final HexaEconomy plugin;
    AuctionGui(HexaEconomy plugin) { this.plugin = plugin; }

    void open(Player player, String query, String category, String sort, int page) {
        plugin.store().listings(query, category, sort, 45, page * 45).whenComplete((rows, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (!player.isOnline()) return;
                    if (error != null) { plugin.text().send(player, plugin.text().message("transaction-failed")); return; }
                    AuctionHolder holder = new AuctionHolder(false, query, category, sort, page, 0);
                    Inventory inventory = Bukkit.createInventory(holder, 54, plugin.text().prefixed("&8Auction House"));
                    holder.inventory = inventory;
                    for (int i = 0; i < rows.size(); i++) {
                        SqliteStore.Listing listing = rows.get(i);
                        try {
                            ItemStack icon = ItemStack.deserializeBytes(listing.item());
                            ItemMeta meta = icon.getItemMeta();
                            List<Component> lore = new ArrayList<>();
                            lore.add(plugin.text().prefixed("&7Seller: &f" + listing.sellerName()));
                            lore.add(plugin.text().prefixed("&7Price: &a" + plugin.getConfig().getString("economy.currency-symbol", "$")
                                    + SqliteStore.money(listing.price())));
                            lore.add(plugin.text().prefixed("&7Listing: &f#" + listing.id()));
                            lore.add(plugin.text().prefixed("&eClick to review purchase."));
                            meta.lore(lore);
                            icon.setItemMeta(meta);
                            inventory.setItem(i, icon);
                            holder.listingIds.put(i, listing.id());
                        } catch (RuntimeException ex) {
                            plugin.getLogger().warning("Skipping invalid auction item on listing #" + listing.id());
                        }
                    }
                    if (page > 0) inventory.setItem(45, button(Material.ARROW, "&ePrevious page"));
                    inventory.setItem(49, button(Material.BARRIER, "&cClose"));
                    if (rows.size() == 45) inventory.setItem(53, button(Material.ARROW, "&eNext page"));
                    player.openInventory(inventory);
                }));
    }

    private void confirm(Player player, long id) {
        plugin.store().listing(id).whenComplete((found, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (error != null) { plugin.text().send(player, plugin.text().message("transaction-failed")); return; }
                    if (found == null) { plugin.text().send(player, "&cThat listing is no longer available."); return; }
                    ItemStack item;
                    try { item = ItemStack.deserializeBytes(found.item()); }
                    catch (RuntimeException ex) { plugin.text().send(player, "&cThat listing contains an invalid item."); return; }
                    AuctionHolder holder = new AuctionHolder(true, null, null, "newest", 0, id);
                    Inventory inventory = Bukkit.createInventory(holder, 27, plugin.text().prefixed("&8Confirm auction purchase"));
                    holder.inventory = inventory;
                    item.setAmount(Math.min(item.getAmount(), item.getMaxStackSize()));
                    inventory.setItem(4, item);
                    inventory.setItem(13, button(Material.LIME_CONCRETE, "&aConfirm for "
                            + plugin.getConfig().getString("economy.currency-symbol", "$") + SqliteStore.money(found.price())));
                    inventory.setItem(22, button(Material.BARRIER, "&cCancel"));
                    player.openInventory(inventory);
                }));
    }

    @EventHandler public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder(false) instanceof AuctionHolder holder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getView().getTopInventory() || event.getClick().isShiftClick()
                || event.getClick() == ClickType.DOUBLE_CLICK || event.getClick() == ClickType.NUMBER_KEY) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;
        int slot = event.getRawSlot();
        if (slot < 0 || slot >= holder.inventory.getSize()) return;
        if (!holder.confirm) {
            if (slot == 49) { player.closeInventory(); return; }
            if (slot == 45) { open(player, holder.query, holder.category, holder.sort, Math.max(0, holder.page - 1)); return; }
            if (slot == 53) { open(player, holder.query, holder.category, holder.sort, holder.page + 1); return; }
            Long id = holder.listingIds.get(slot);
            if (id != null) confirm(player, id);
        } else {
            if (slot == 22) { open(player, holder.query, holder.category, holder.sort, holder.page); return; }
            if (slot == 13) purchase(player, holder.listingId);
        }
    }

    @EventHandler public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder(false) instanceof AuctionHolder) event.setCancelled(true);
    }

    private void purchase(Player buyer, long id) {
        plugin.store().purchaseListing(id, buyer.getUniqueId(), buyer.getName(),
                plugin.getConfig().getBoolean("auction.allow-self-purchase", false),
                plugin.getConfig().getDouble("auction.tax-percent", 0)).whenComplete((result, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (error != null) { plugin.text().send(buyer, plugin.text().message("transaction-failed")); return; }
                    if (!result.success()) {
                        String message = switch (result.reason()) {
                            case "self" -> "&cYou cannot buy your own listing.";
                            case "funds" -> plugin.text().message("insufficient-funds");
                            case "expired", "missing", "raced" -> "&cThat listing is no longer available.";
                            default -> plugin.text().message("transaction-failed");
                        };
                        plugin.text().send(buyer, message); return;
                    }
                    plugin.economy().invalidate(buyer.getUniqueId());
                    plugin.economy().invalidate(result.seller());
                    plugin.text().send(buyer, "&aPurchase complete. Use &f/ah claim &ato collect your item.");
                    Player seller = Bukkit.getPlayer(result.seller());
                    if (seller != null) plugin.text().send(seller, "&aYour auction listing #" + id + " sold for "
                            + plugin.getConfig().getString("economy.currency-symbol", "$") + SqliteStore.money(result.price()) + ".");
                    playerReturn(buyer, null, null, "newest", 0);
                }));
    }

    private void playerReturn(Player player, String query, String category, String sort, int page) {
        open(player, query, category, sort, page);
    }

    private ItemStack button(Material material, String text) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(plugin.text().prefixed(text));
        item.setItemMeta(meta);
        return item;
    }

    private static final class AuctionHolder implements InventoryHolder {
        final boolean confirm;
        final String query, category, sort;
        final int page;
        final long listingId;
        final Map<Integer, Long> listingIds = new HashMap<>();
        Inventory inventory;
        AuctionHolder(boolean confirm, String query, String category, String sort, int page, long listingId) {
            this.confirm = confirm; this.query = query; this.category = category; this.sort = sort;
            this.page = page; this.listingId = listingId;
        }
        @Override public Inventory getInventory() { return inventory; }
    }
}
