package com.hexamc.economy;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.Style;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.command.CommandSender;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Hex color and legacy-format parser shared by every HexaEconomy message. */
public final class HexaText {
    private static final Pattern HEX = Pattern.compile("&#([A-Fa-f0-9]{6})");
    private static final String DEFAULT_PREFIX =
            "&#FBE700&l&o&nH&#C9E533&l&o&ne&#97E266&l&o&nx&#64E099&l&o&na&#32DDCC&l&o&nM&#00DBFF&l&o&nC";
    private final HexaEconomy plugin;

    public HexaText(HexaEconomy plugin) { this.plugin = plugin; }

    public void send(CommandSender recipient, String message) {
        recipient.sendMessage(prefixed(message));
    }

    public Component prefixed(String message) {
        String prefix = plugin.getConfig().getString("branding.prefix", DEFAULT_PREFIX);
        return parse(prefix).append(Component.space()).append(parse(message));
    }

    public Component parse(String input) {
        Component out = Component.empty();
        Style style = Style.empty();
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < input.length();) {
            if (input.startsWith("&#", i) && i + 8 <= input.length()) {
                String value = input.substring(i + 2, i + 8);
                if (value.matches("[A-Fa-f0-9]{6}")) {
                    out = append(out, text, style);
                    text.setLength(0);
                    style = style.color(TextColor.fromHexString("#" + value));
                    i += 8;
                    continue;
                }
            }
            if (input.charAt(i) == '&' && i + 1 < input.length()) {
                char code = Character.toLowerCase(input.charAt(i + 1));
                TextDecoration decoration = switch (code) {
                    case 'l' -> TextDecoration.BOLD;
                    case 'o' -> TextDecoration.ITALIC;
                    case 'n' -> TextDecoration.UNDERLINED;
                    case 'm' -> TextDecoration.STRIKETHROUGH;
                    case 'k' -> TextDecoration.OBFUSCATED;
                    default -> null;
                };
                if (decoration != null) {
                    out = append(out, text, style);
                    text.setLength(0);
                    style = style.decoration(decoration, true);
                    i += 2;
                    continue;
                }
                NamedTextColor color = legacyColor(code);
                if (color != null) {
                    out = append(out, text, style);
                    text.setLength(0);
                    style = Style.empty().color(color);
                    i += 2;
                    continue;
                }
                if (code == 'r') {
                    out = append(out, text, style);
                    text.setLength(0);
                    style = Style.empty();
                    i += 2;
                    continue;
                }
            }
            text.append(input.charAt(i++));
        }
        return append(out, text, style);
    }

    private Component append(Component root, StringBuilder text, Style style) {
        return text.isEmpty() ? root : root.append(Component.text(text.toString(), style));
    }

    private NamedTextColor legacyColor(char code) {
        return switch (Character.toLowerCase(code)) {
            case '0' -> NamedTextColor.BLACK; case '1' -> NamedTextColor.DARK_BLUE;
            case '2' -> NamedTextColor.DARK_GREEN; case '3' -> NamedTextColor.DARK_AQUA;
            case '4' -> NamedTextColor.DARK_RED; case '5' -> NamedTextColor.DARK_PURPLE;
            case '6' -> NamedTextColor.GOLD; case '7' -> NamedTextColor.GRAY;
            case '8' -> NamedTextColor.DARK_GRAY; case '9' -> NamedTextColor.BLUE;
            case 'a' -> NamedTextColor.GREEN; case 'b' -> NamedTextColor.AQUA;
            case 'c' -> NamedTextColor.RED; case 'd' -> NamedTextColor.LIGHT_PURPLE;
            case 'e' -> NamedTextColor.YELLOW; case 'f' -> NamedTextColor.WHITE;
            default -> null;
        };
    }

    public String message(String key) {
        return plugin.getMessages().getString("messages." + key, "&cMissing message: " + key);
    }

    public static String defaultPrefix() { return DEFAULT_PREFIX; }
}
