package com.hexamc.economy;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

public final class HexaEconomy extends JavaPlugin {
    private SqliteStore store;
    private HexaText text;
    private FileConfiguration messages;
    private EconomyProvider economy;
    private ShopGui shopGui;
    private AuctionGui auctionGui;
    private boolean ready;

    @Override public void onEnable() {
        saveDefaultConfig();
        saveResource("messages.yml", false);
        saveResource("shop.yml", false);
        reloadLocalConfigs();
        text = new HexaText(this);
        store = new SqliteStore(new File(getDataFolder(), "economy.db"));
        economy = new EconomyProvider(this);
        shopGui = new ShopGui(this);
        auctionGui = new AuctionGui(this);
        getServer().getPluginManager().registerEvents(shopGui, this);
        getServer().getPluginManager().registerEvents(auctionGui, this);
        HexaCommands commandHandler = new HexaCommands(this);
        for (String name : new String[]{"shop", "sellgui", "ah", "pay", "bal", "baltop", "eco", "hexeconomy"}) {
            PluginCommand command = getCommand(name);
            if (command != null) {
                command.setExecutor(commandHandler);
                command.setTabCompleter(commandHandler);
            }
        }
        store.initialize().whenComplete((ignored, error) -> Bukkit.getScheduler().runTask(this, () -> {
            if (error != null) {
                getLogger().log(Level.SEVERE, "SQLite initialization failed; economy commands are disabled.", error);
                return;
            }
            ready = true;
            Bukkit.getServicesManager().register(Economy.class, economy, this, ServicePriority.High);
            if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
                try { new HexaPlaceholders(this).register(); }
                catch (Throwable t) { getLogger().log(Level.WARNING, "Could not register PlaceholderAPI expansion.", t); }
            }
            for (OfflinePlayer player : Bukkit.getOnlinePlayers()) loadPlayer(player);
            Bukkit.getScheduler().runTaskTimerAsynchronously(this, () ->
                    store.expireListings().thenAccept(expired -> {
                        if (expired > 0) getLogger().info("Expired " + expired + " auction listing(s); items moved to player claims.");
                    }).exceptionally(error -> { getLogger().log(Level.WARNING, "Auction expiry check failed.", error); return null; }),
                    20L * 60L, 20L * 60L);
            getLogger().info("HexaEconomy is ready. SQLite data is stored in " + new File(getDataFolder(), "economy.db").getName());
        }));
        Bukkit.getPluginManager().registerEvents(new org.bukkit.event.Listener() {
            @org.bukkit.event.EventHandler public void onJoin(org.bukkit.event.player.PlayerJoinEvent event) {
                if (ready) loadPlayer(event.getPlayer());
            }
        }, this);
    }

    private void loadPlayer(OfflinePlayer player) {
        String name = Objects.requireNonNullElse(player.getName(), player.getUniqueId().toString());
        store.balance(player.getUniqueId(), name, getConfig().getDouble("economy.starting-balance", 100.0))
                .whenComplete((value, error) -> {
                    if (error != null) getLogger().log(Level.WARNING, "Could not load account " + player.getUniqueId(), error);
                    else economy.cache(player.getUniqueId(), value);
                });
        store.updateName(player.getUniqueId(), name);
    }

    public void reloadLocalConfigs() {
        reloadConfig();
        if (new File(getDataFolder(), "messages.yml").isFile()) {
            messages = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(new File(getDataFolder(), "messages.yml"));
        }
        if (shopGui != null) shopGui.reload();
    }

    public void reloadMessages() {
        messages = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(new File(getDataFolder(), "messages.yml"));
    }
    public FileConfiguration getMessages() { return messages; }
    public SqliteStore store() { return store; }
    public HexaText text() { return text; }
    public EconomyProvider economy() { return economy; }
    public ShopGui shopGui() { return shopGui; }
    public AuctionGui auctionGui() { return auctionGui; }
    public boolean isReady() { return ready; }

    public CompletableFuture<Double> balance(UUID uuid, String name) {
        return store.balance(uuid, name, getConfig().getDouble("economy.starting-balance", 100.0))
                .thenApply(value -> { economy.cache(uuid, value); return value; });
    }

    @Override public void onDisable() {
        ready = false;
        if (economy != null) Bukkit.getServicesManager().unregister(Economy.class, economy);
        if (store != null) store.close();
    }
}
