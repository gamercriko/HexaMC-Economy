package com.hexamc.economy;

import org.bukkit.Bukkit;

import java.io.File;
import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

/**
 * All JDBC work is serialized on one daemon worker. Bukkit APIs and inventories
 * are deliberately never touched from this executor.
 */
public final class SqliteStore implements AutoCloseable {
    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "HexaEconomy-SQLite");
        t.setDaemon(true);
        return t;
    });
    private final File file;
    private volatile Connection connection;

    public SqliteStore(File file) { this.file = file; }

    public CompletableFuture<Void> initialize() {
        return supply(() -> {
            file.getParentFile().mkdirs();
            connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
            try (Statement s = connection.createStatement()) {
                s.execute("PRAGMA journal_mode=WAL");
                s.execute("PRAGMA foreign_keys=ON");
                s.execute("PRAGMA busy_timeout=5000");
                s.execute("""
                    CREATE TABLE IF NOT EXISTS accounts(
                      uuid TEXT PRIMARY KEY, name TEXT NOT NULL, balance TEXT NOT NULL,
                      updated_at INTEGER NOT NULL
                    )""");
                s.execute("""
                    CREATE TABLE IF NOT EXISTS transactions(
                      id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT, target TEXT,
                      type TEXT NOT NULL, amount TEXT NOT NULL, created_at INTEGER NOT NULL
                    )""");
                s.execute("""
                    CREATE TABLE IF NOT EXISTS listings(
                      id INTEGER PRIMARY KEY AUTOINCREMENT, seller_uuid TEXT NOT NULL,
                      seller_name TEXT NOT NULL, item BLOB NOT NULL, price TEXT NOT NULL,
                      category TEXT NOT NULL DEFAULT 'MISCELLANEOUS', created_at INTEGER NOT NULL,
                      expires_at INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'ACTIVE',
                      item_key TEXT NOT NULL DEFAULT ''
                    )""");
                s.execute("""
                    CREATE TABLE IF NOT EXISTS claims(
                      id INTEGER PRIMARY KEY AUTOINCREMENT, owner_uuid TEXT NOT NULL,
                      item BLOB, amount TEXT, kind TEXT NOT NULL, created_at INTEGER NOT NULL
                    )""");
                s.execute("CREATE INDEX IF NOT EXISTS listings_status_expiry ON listings(status, expires_at)");
                s.execute("CREATE INDEX IF NOT EXISTS claims_owner ON claims(owner_uuid)");
            }
            ensureColumn("listings", "item_key", "TEXT NOT NULL DEFAULT ''");
            createStartupBackup();
            return null;
        });
    }

    public CompletableFuture<Double> balance(UUID uuid, String name, double startingBalance) {
        return supply(() -> {
            try (PreparedStatement q = connection.prepareStatement("SELECT balance FROM accounts WHERE uuid=?")) {
                q.setString(1, uuid.toString());
                try (ResultSet rs = q.executeQuery()) {
                    if (rs.next()) return Double.parseDouble(rs.getString(1));
                }
            }
            try (PreparedStatement p = connection.prepareStatement(
                    "INSERT OR IGNORE INTO accounts(uuid,name,balance,updated_at) VALUES(?,?,?,?)")) {
                p.setString(1, uuid.toString()); p.setString(2, name);
                p.setString(3, money(startingBalance)); p.setLong(4, Instant.now().toEpochMilli()); p.executeUpdate();
            }
            return startingBalance;
        });
    }

    public CompletableFuture<Boolean> transfer(UUID from, String fromName, UUID to, String toName,
                                                double amount, double feePercent) {
        return supply(() -> {
            connection.setAutoCommit(false);
            try {
                ensureAccount(from, fromName);
                ensureAccount(to, toName);
                double fee = round(amount * feePercent / 100.0);
                double debit = round(amount + fee);
                double fromBalance = readBalance(from);
                if (fromBalance + 1e-9 < debit) { connection.rollback(); return false; }
                writeBalance(from, fromBalance - debit, fromName);
                writeBalance(to, readBalance(to) + amount, toName);
                log(from, to, "PAY", amount);
                if (fee > 0) log(from, null, "TRANSFER_FEE", fee);
                connection.commit();
                return true;
            } catch (Throwable t) {
                connection.rollback();
                throw t;
            } finally { connection.setAutoCommit(true); }
        });
    }

    public CompletableFuture<Boolean> change(UUID uuid, String name, double amount, String type) {
        return supply(() -> {
            connection.setAutoCommit(false);
            try {
                ensureAccount(uuid, name);
                double old = readBalance(uuid);
                double next = switch (type) {
                    case "GIVE" -> old + amount;
                    case "TAKE" -> old - amount;
                    case "RESET" -> 0d;
                    default -> amount;
                };
                next = round(next);
                if (!Double.isFinite(next) || next < 0) { connection.rollback(); return false; }
                writeBalance(uuid, next, name);
                log(null, uuid, type, type.equals("RESET") ? old : amount);
                connection.commit();
                return true;
            } catch (Throwable t) {
                connection.rollback();
                throw t;
            } finally { connection.setAutoCommit(true); }
        });
    }

    public CompletableFuture<List<Rank>> top(int limit, int offset, Set<UUID> excluded) {
        return supply(() -> {
            List<Rank> out = new ArrayList<>();
            try (Statement s = connection.createStatement();
                 ResultSet rs = s.executeQuery("SELECT uuid,name,balance FROM accounts ORDER BY CAST(balance AS REAL) DESC, name COLLATE NOCASE ASC")) {
                int row = 0, added = 0;
                while (rs.next()) {
                    UUID uuid = UUID.fromString(rs.getString(1));
                    if (excluded.contains(uuid)) continue;
                    if (row++ < offset) continue;
                    if (added++ >= limit) break;
                    out.add(new Rank(uuid, rs.getString(2), Double.parseDouble(rs.getString(3))));
                }
            }
            return out;
        });
    }

    public CompletableFuture<Integer> activeListingCount(UUID seller) {
        return supply(() -> {
            try (PreparedStatement p = connection.prepareStatement(
                    "SELECT COUNT(*) FROM listings WHERE seller_uuid=? AND status='ACTIVE' AND expires_at>?")) {
                p.setString(1, seller.toString()); p.setLong(2, Instant.now().toEpochMilli());
                try (ResultSet rs = p.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
            }
        });
    }

    public CompletableFuture<Listing> listing(long id) {
        return supply(() -> {
            try (PreparedStatement p = connection.prepareStatement(
                    "SELECT id,seller_uuid,seller_name,item,price,created_at,expires_at FROM listings WHERE id=? AND status='ACTIVE' AND expires_at>?")) {
                p.setLong(1, id); p.setLong(2, Instant.now().toEpochMilli());
                try (ResultSet rs = p.executeQuery()) {
                    return rs.next() ? new Listing(rs.getLong(1), UUID.fromString(rs.getString(2)), rs.getString(3),
                            rs.getBytes(4), Double.parseDouble(rs.getString(5)), rs.getLong(6), rs.getLong(7)) : null;
                }
            }
        });
    }

    public CompletableFuture<Void> addItemClaim(UUID owner, byte[] item) {
        return supply(() -> { insertItemClaim(owner, item); return null; });
    }

    public CompletableFuture<Long> createListing(UUID seller, String name, byte[] item, String itemKey,
                                                 String category, double price, double fee, long expirationMillis) {
        return supply(() -> {
            connection.setAutoCommit(false);
            try {
                ensureAccount(seller, name);
                double balance = readBalance(seller);
                if (balance + 1e-9 < fee) { connection.rollback(); return -1L; }
                if (fee > 0) {
                    writeBalance(seller, round(balance - fee), name);
                    log(seller, null, "AUCTION_FEE", fee);
                }
                long now = Instant.now().toEpochMilli();
                long id;
                try (PreparedStatement p = connection.prepareStatement(
                        "INSERT INTO listings(seller_uuid,seller_name,item,price,category,created_at,expires_at,status,item_key) VALUES(?,?,?,?,?,?,?,'ACTIVE',?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    p.setString(1, seller.toString()); p.setString(2, name); p.setBytes(3, item);
                    p.setString(4, money(price)); p.setString(5, category.toUpperCase(Locale.ROOT));
                    p.setLong(6, now); p.setLong(7, expirationMillis); p.setString(8, itemKey.toUpperCase(Locale.ROOT));
                    p.executeUpdate();
                    try (ResultSet keys = p.getGeneratedKeys()) { if (!keys.next()) throw new SQLException("No listing id generated"); id = keys.getLong(1); }
                }
                connection.commit();
                return id;
            } catch (Throwable t) { connection.rollback(); throw t; }
            finally { connection.setAutoCommit(true); }
        });
    }

    public CompletableFuture<List<Listing>> listings(String search, String category, String sort, int limit, int offset) {
        return supply(() -> {
            String order = switch (sort == null ? "newest" : sort.toLowerCase(Locale.ROOT)) {
                case "price_asc" -> "CAST(price AS REAL) ASC, created_at DESC";
                case "price_desc" -> "CAST(price AS REAL) DESC, created_at DESC";
                case "oldest" -> "created_at ASC";
                default -> "created_at DESC";
            };
            StringBuilder sql = new StringBuilder("SELECT id,seller_uuid,seller_name,item,price,created_at,expires_at FROM listings WHERE status='ACTIVE' AND expires_at>?");
            if (search != null && !search.isBlank()) sql.append(" AND LOWER(seller_name||' '||item_key||' '||CAST(id AS TEXT)) LIKE LOWER(?)");
            if (category != null && !category.isBlank()) sql.append(" AND category=?");
            sql.append(" ORDER BY ").append(order).append(" LIMIT ? OFFSET ?");
            try (PreparedStatement p = connection.prepareStatement(sql.toString())) {
                int i = 1; p.setLong(i++, Instant.now().toEpochMilli());
                if (search != null && !search.isBlank()) p.setString(i++, "%" + search + "%");
                if (category != null && !category.isBlank()) p.setString(i++, category.toUpperCase(Locale.ROOT));
                p.setInt(i++, limit); p.setInt(i, offset);
                try (ResultSet rs = p.executeQuery()) {
                    List<Listing> out = new ArrayList<>();
                    while (rs.next()) out.add(new Listing(rs.getLong(1), UUID.fromString(rs.getString(2)),
                            rs.getString(3), rs.getBytes(4), Double.parseDouble(rs.getString(5)),
                            rs.getLong(6), rs.getLong(7)));
                    return out;
                }
            }
        });
    }

    public CompletableFuture<Boolean> cancelListing(long id, UUID seller) {
        return supply(() -> {
            connection.setAutoCommit(false);
            try {
                byte[] item;
                try (PreparedStatement p = connection.prepareStatement(
                        "SELECT item FROM listings WHERE id=? AND seller_uuid=? AND status='ACTIVE'")) {
                    p.setLong(1, id); p.setString(2, seller.toString());
                    try (ResultSet rs = p.executeQuery()) { if (!rs.next()) { connection.rollback(); return false; } item = rs.getBytes(1); }
                }
                try (PreparedStatement p = connection.prepareStatement("UPDATE listings SET status='CANCELLED' WHERE id=? AND status='ACTIVE'")) {
                    p.setLong(1, id); if (p.executeUpdate() != 1) { connection.rollback(); return false; }
                }
                insertItemClaim(seller, item);
                connection.commit(); return true;
            } catch (Throwable t) { connection.rollback(); throw t; }
            finally { connection.setAutoCommit(true); }
        });
    }

    public CompletableFuture<Boolean> adminRemoveListing(long id) {
        return supply(() -> {
            connection.setAutoCommit(false);
            try {
                UUID seller; byte[] item;
                try (PreparedStatement p = connection.prepareStatement(
                        "SELECT seller_uuid,item FROM listings WHERE id=? AND status='ACTIVE'")) {
                    p.setLong(1, id);
                    try (ResultSet rs = p.executeQuery()) {
                        if (!rs.next()) { connection.rollback(); return false; }
                        seller = UUID.fromString(rs.getString(1)); item = rs.getBytes(2);
                    }
                }
                try (PreparedStatement p = connection.prepareStatement("UPDATE listings SET status='REMOVED' WHERE id=? AND status='ACTIVE'")) {
                    p.setLong(1, id); if (p.executeUpdate() != 1) { connection.rollback(); return false; }
                }
                insertItemClaim(seller, item);
                connection.commit(); return true;
            } catch (Throwable t) { connection.rollback(); throw t; }
            finally { connection.setAutoCommit(true); }
        });
    }

    public CompletableFuture<Purchase> purchaseListing(long id, UUID buyer, String buyerName,
                                                        boolean allowSelfPurchase, double taxPercent) {
        return supply(() -> {
            connection.setAutoCommit(false);
            try {
                UUID seller; String sellerName; byte[] item; double price; long expires;
                try (PreparedStatement p = connection.prepareStatement(
                        "SELECT seller_uuid,seller_name,item,price,expires_at FROM listings WHERE id=? AND status='ACTIVE'")) {
                    p.setLong(1, id);
                    try (ResultSet rs = p.executeQuery()) {
                        if (!rs.next()) { connection.rollback(); return new Purchase(false, "missing", null, null, 0); }
                        seller = UUID.fromString(rs.getString(1)); sellerName = rs.getString(2);
                        item = rs.getBytes(3); price = Double.parseDouble(rs.getString(4)); expires = rs.getLong(5);
                    }
                }
                if (expires <= Instant.now().toEpochMilli()) { connection.rollback(); return new Purchase(false, "expired", seller, sellerName, 0); }
                if (!allowSelfPurchase && seller.equals(buyer)) { connection.rollback(); return new Purchase(false, "self", seller, sellerName, 0); }
                ensureAccount(buyer, buyerName); ensureAccount(seller, sellerName);
                double buyerBalance = readBalance(buyer);
                if (buyerBalance + 1e-9 < price) { connection.rollback(); return new Purchase(false, "funds", seller, sellerName, 0); }
                double tax = round(price * taxPercent / 100.0);
                try (PreparedStatement p = connection.prepareStatement("UPDATE listings SET status='SOLD' WHERE id=? AND status='ACTIVE'")) {
                    p.setLong(1, id); if (p.executeUpdate() != 1) { connection.rollback(); return new Purchase(false, "raced", seller, sellerName, 0); }
                }
                writeBalance(buyer, round(buyerBalance - price), buyerName);
                writeBalance(seller, round(readBalance(seller) + price - tax), sellerName);
                log(buyer, seller, "AUCTION_PURCHASE", price);
                if (tax > 0) log(buyer, null, "AUCTION_TAX", tax);
                insertItemClaim(buyer, item);
                connection.commit();
                return new Purchase(true, "ok", seller, sellerName, price);
            } catch (Throwable t) { connection.rollback(); throw t; }
            finally { connection.setAutoCommit(true); }
        });
    }

    public CompletableFuture<List<Claim>> claims(UUID owner) {
        return supply(() -> {
            try (PreparedStatement p = connection.prepareStatement(
                    "SELECT id,item,amount,kind FROM claims WHERE owner_uuid=? ORDER BY id")) {
                p.setString(1, owner.toString());
                try (ResultSet rs = p.executeQuery()) {
                    List<Claim> out = new ArrayList<>();
                    while (rs.next()) out.add(new Claim(rs.getLong(1), rs.getBytes(2), rs.getString(3), rs.getString(4)));
                    return out;
                }
            }
        });
    }

    public CompletableFuture<Boolean> consumeClaim(long id, UUID owner) {
        return supply(() -> {
            try (PreparedStatement p = connection.prepareStatement("DELETE FROM claims WHERE id=? AND owner_uuid=?")) {
                p.setLong(1, id); p.setString(2, owner.toString()); return p.executeUpdate() == 1;
            }
        });
    }

    public CompletableFuture<Integer> expireListings() {
        return supply(() -> {
            connection.setAutoCommit(false);
            try {
                List<Map.Entry<Long, ClaimSeed>> expired = new ArrayList<>();
                try (PreparedStatement p = connection.prepareStatement(
                        "SELECT id,seller_uuid,item FROM listings WHERE status='ACTIVE' AND expires_at<=?")) {
                    p.setLong(1, Instant.now().toEpochMilli());
                    try (ResultSet rs = p.executeQuery()) {
                        while (rs.next()) expired.add(Map.entry(rs.getLong(1),
                                new ClaimSeed(UUID.fromString(rs.getString(2)), rs.getBytes(3))));
                    }
                }
                try (PreparedStatement p = connection.prepareStatement("UPDATE listings SET status='EXPIRED' WHERE id=? AND status='ACTIVE'")) {
                    for (var entry : expired) {
                        p.setLong(1, entry.getKey());
                        if (p.executeUpdate() == 1) insertItemClaim(entry.getValue().owner, entry.getValue().item);
                    }
                }
                connection.commit(); return expired.size();
            } catch (Throwable t) { connection.rollback(); throw t; }
            finally { connection.setAutoCommit(true); }
        });
    }

    private void insertItemClaim(UUID owner, byte[] item) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement(
                "INSERT INTO claims(owner_uuid,item,kind,created_at) VALUES(?,?,'ITEM',?)")) {
            p.setString(1, owner.toString()); p.setBytes(2, item); p.setLong(3, Instant.now().toEpochMilli()); p.executeUpdate();
        }
    }

    private void ensureColumn(String table, String column, String definition) throws SQLException {
        boolean present = false;
        try (Statement s = connection.createStatement(); ResultSet rs = s.executeQuery("PRAGMA table_info(" + table + ")")) {
            while (rs.next()) if (column.equalsIgnoreCase(rs.getString("name"))) present = true;
        }
        if (!present) try (Statement s = connection.createStatement()) {
            s.execute("ALTER TABLE " + table + " ADD COLUMN " + column + " " + definition);
        }
    }

    private void createStartupBackup() throws SQLException {
        if (!file.exists() || file.length() == 0) return;
        File backups = new File(file.getParentFile(), "backups");
        if (!backups.exists() && !backups.mkdirs()) throw new SQLException("Could not create SQLite backup directory");
        String stamp = java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS")
                .withZone(java.time.ZoneOffset.UTC).format(Instant.now());
        File destination = new File(backups, "economy-" + stamp + ".db");
        try (Statement s = connection.createStatement()) {
            s.execute("PRAGMA wal_checkpoint(FULL)");
            s.execute("VACUUM INTO '" + destination.getAbsolutePath().replace("'", "''") + "'");
        }
    }

    public CompletableFuture<Void> updateName(UUID uuid, String name) {
        return supply(() -> {
            try (PreparedStatement p = connection.prepareStatement("UPDATE accounts SET name=?,updated_at=? WHERE uuid=?")) {
                p.setString(1, name); p.setLong(2, Instant.now().toEpochMilli()); p.setString(3, uuid.toString()); p.executeUpdate();
            }
            return null;
        });
    }

    private void ensureAccount(UUID uuid, String name) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement(
                "INSERT OR IGNORE INTO accounts(uuid,name,balance,updated_at) VALUES(?,?,?,?)")) {
            p.setString(1, uuid.toString()); p.setString(2, name); p.setString(3, "0.00");
            p.setLong(4, Instant.now().toEpochMilli()); p.executeUpdate();
        }
    }
    private double readBalance(UUID uuid) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement("SELECT balance FROM accounts WHERE uuid=?")) {
            p.setString(1, uuid.toString());
            try (ResultSet r = p.executeQuery()) { return r.next() ? Double.parseDouble(r.getString(1)) : 0; }
        }
    }
    private void writeBalance(UUID uuid, double value, String name) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement("UPDATE accounts SET balance=?,name=?,updated_at=? WHERE uuid=?")) {
            p.setString(1, money(value)); p.setString(2, name); p.setLong(3, Instant.now().toEpochMilli());
            p.setString(4, uuid.toString()); p.executeUpdate();
        }
    }
    private void log(UUID actor, UUID target, String type, double amount) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement(
                "INSERT INTO transactions(actor,target,type,amount,created_at) VALUES(?,?,?,?,?)")) {
            p.setString(1, actor == null ? null : actor.toString());
            p.setString(2, target == null ? null : target.toString());
            p.setString(3, type); p.setString(4, money(amount));
            p.setLong(5, Instant.now().toEpochMilli()); p.executeUpdate();
        }
    }
    public static String money(double amount) { return String.format(Locale.US, "%.2f", amount); }
    private static double round(double amount) { return Math.round(amount * 100.0) / 100.0; }

    private <T> CompletableFuture<T> supply(Callable<T> task) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                return task.call();
            } catch (Exception e) { throw new CompletionException(e); }
        }, worker);
    }
    @Override public void close() {
        worker.shutdown();
        try { if (!worker.awaitTermination(5, TimeUnit.SECONDS)) worker.shutdownNow(); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); worker.shutdownNow(); }
        try { if (connection != null) connection.close(); } catch (SQLException ignored) {}
    }
    public record Rank(UUID uuid, String name, double balance) {}
    public record Listing(long id, UUID seller, String sellerName, byte[] item, double price, long createdAt, long expiresAt) {}
    public record Purchase(boolean success, String reason, UUID seller, String sellerName, double price) {}
    public record Claim(long id, byte[] item, String amount, String kind) {}
    private record ClaimSeed(UUID owner, byte[] item) {}
}
