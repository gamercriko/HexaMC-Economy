package com.hexamc.economy;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.CompletionException;

final class HexaCommands implements CommandExecutor, TabCompleter {
    private final HexaEconomy plugin;
    HexaCommands(HexaEconomy plugin) { this.plugin = plugin; }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String root = command.getName().toLowerCase(Locale.ROOT);
        String permission = switch (root) {
            case "shop" -> "hexa.shop"; case "sellgui" -> "hexa.sell"; case "ah" -> "hexa.ah";
            case "pay" -> "hexa.pay"; case "bal" -> "hexa.balance"; case "baltop" -> "hexa.baltop";
            case "eco" -> "hexa.eco"; case "hexeconomy" -> "hexa.admin"; default -> "";
        };
        if (!permission.isEmpty() && !sender.hasPermission(permission)) {
            noPermission(sender);
            return true;
        }
        if (!plugin.isReady() && !root.equals("hexeconomy")) {
            plugin.text().send(sender, plugin.text().message("database-not-ready"));
            return true;
        }
        return switch (root) {
            case "bal" -> balance(sender, args);
            case "pay" -> pay(sender, args);
            case "eco" -> eco(sender, args);
            case "baltop" -> baltop(sender, args);
            case "hexeconomy" -> admin(sender, args);
            case "shop" -> openShop(sender, false, args);
            case "sellgui" -> openShop(sender, true, args);
            case "ah" -> auction(sender, args);
            default -> false;
        };
    }

    private boolean balance(CommandSender sender, String[] args) {
        if (args.length > 1) { usage(sender, "/bal [player]"); return true; }
        OfflinePlayer target;
        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                plugin.text().send(sender, plugin.text().message("player-only")); return true;
            }
            target = player;
        } else {
            if (!sender.hasPermission("hexa.balance.others")) { noPermission(sender); return true; }
            target = Bukkit.getOfflinePlayer(args[0]);
            if (!target.hasPlayedBefore() && !target.isOnline()) {
                plugin.text().send(sender, plugin.text().message("player-not-found").replace("%player%", args[0])); return true;
            }
        }
        String name = Objects.requireNonNullElse(target.getName(), args.length == 0 ? sender.getName() : args[0]);
        plugin.balance(target.getUniqueId(), name).whenComplete((amount, error) -> main(() -> {
            if (error != null) { report(sender, error); return; }
            String key = target.getUniqueId().equals(sender instanceof Player p ? p.getUniqueId() : null)
                    ? "balance" : "balance-other";
            plugin.text().send(sender, plugin.text().message(key)
                    .replace("%player%", name).replace("%currency%", currency())
                    .replace("%balance%", SqliteStore.money(amount)));
        }));
        return true;
    }

    private boolean pay(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) { plugin.text().send(sender, plugin.text().message("player-only")); return true; }
        if (args.length != 2) { usage(sender, "/pay <player> <amount>"); return true; }
        double amount = parseAmount(args[1]);
        double max = plugin.getConfig().getDouble("economy.max-payment", 1_000_000);
        if (!Double.isFinite(amount) || amount <= 0 || amount > max) {
            plugin.text().send(sender, plugin.text().message("invalid-amount")); return true;
        }
        OfflinePlayer recipient = Bukkit.getOfflinePlayer(args[0]);
        if (recipient.getUniqueId().equals(player.getUniqueId())) {
            plugin.text().send(sender, plugin.text().message("self-pay")); return true;
        }
        if (!recipient.hasPlayedBefore() && !recipient.isOnline()) {
            plugin.text().send(sender, plugin.text().message("player-not-found").replace("%player%", args[0])); return true;
        }
        String toName = Objects.requireNonNullElse(recipient.getName(), args[0]);
        double fee = plugin.getConfig().getDouble("economy.transfer-fee-percent", 0);
        plugin.store().transfer(player.getUniqueId(), player.getName(), recipient.getUniqueId(), toName, amount, fee)
                .whenComplete((ok, error) -> main(() -> {
                    if (error != null) { report(sender, error); return; }
                    if (!ok) { plugin.text().send(sender, plugin.text().message("insufficient-funds")); return; }
                    plugin.economy().invalidate(player.getUniqueId());
                    plugin.economy().invalidate(recipient.getUniqueId());
                    plugin.text().send(sender, plugin.text().message("paid").replace("%currency%", currency())
                            .replace("%amount%", SqliteStore.money(amount)).replace("%player%", toName));
                    if (recipient.isOnline()) plugin.text().send(recipient.getPlayer(), plugin.text().message("received")
                            .replace("%currency%", currency()).replace("%amount%", SqliteStore.money(amount))
                            .replace("%player%", player.getName()));
                }));
        return true;
    }

    private boolean eco(CommandSender sender, String[] args) {
        if (args.length < 2 || args.length > 3) { usage(sender, "/eco <give|take|set|reset> <player> [amount]"); return true; }
        String operation = args[0].toLowerCase(Locale.ROOT);
        if (!Set.of("give", "take", "set", "reset").contains(operation)) { usage(sender, "/eco <give|take|set|reset> <player> [amount]"); return true; }
        if (operation.equals("reset") ? args.length != 2 : args.length != 3) { usage(sender, "/eco <give|take|set|reset> <player> [amount]"); return true; }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        String name = Objects.requireNonNullElse(target.getName(), args[1]);
        double amount = operation.equals("reset") ? 0 : parseAmount(args[2]);
        if (!operation.equals("reset") && (!Double.isFinite(amount) || amount <= 0)) {
            plugin.text().send(sender, plugin.text().message("invalid-amount")); return true;
        }
        String type = switch (operation) { case "give" -> "GIVE"; case "take" -> "TAKE"; case "set" -> "SET"; default -> "RESET"; };
        plugin.store().change(target.getUniqueId(), name, amount, type).whenComplete((ok, error) -> main(() -> {
            if (error != null) { report(sender, error); return; }
            if (!ok) { plugin.text().send(sender, plugin.text().message("transaction-failed")); return; }
            plugin.economy().invalidate(target.getUniqueId());
            plugin.balance(target.getUniqueId(), name).thenAccept(balance -> main(() -> plugin.text().send(sender,
                    plugin.text().message("eco-updated").replace("%player%", name).replace("%currency%", currency())
                            .replace("%balance%", SqliteStore.money(balance)))));
        }));
        return true;
    }

    private boolean baltop(CommandSender sender, String[] args) {
        int page = 1;
        if (args.length > 1) { usage(sender, "/baltop [page]"); return true; }
        if (args.length == 1) try { page = Integer.parseInt(args[0]); } catch (NumberFormatException ignored) {}
        if (page < 1 || page > 10000) { plugin.text().send(sender, plugin.text().message("invalid-amount")); return true; }
        Set<UUID> excluded = new HashSet<>();
        for (String raw : plugin.getConfig().getStringList("economy.excluded-baltop-uuids")) {
            try { excluded.add(UUID.fromString(raw)); } catch (IllegalArgumentException ignored) {}
        }
        int requestedPage = page;
        plugin.store().top(10, (page - 1) * 10, excluded).whenComplete((rows, error) -> main(() -> {
            if (error != null) { report(sender, error); return; }
            if (rows.isEmpty()) { plugin.text().send(sender, plugin.text().message("baltop-empty")); return; }
            plugin.text().send(sender, "&6Richest players &7(Page " + requestedPage + ")");
            for (int i = 0; i < rows.size(); i++) {
                SqliteStore.Rank row = rows.get(i);
                plugin.text().send(sender, "&e#" + ((requestedPage - 1) * 10 + i + 1) + " &f" + row.name()
                        + " &8— &a" + currency() + SqliteStore.money(row.balance()));
            }
        }));
        return true;
    }

    private boolean admin(CommandSender sender, String[] args) {
        if (args.length != 1) { usage(sender, "/hexeconomy <reload|version>"); return true; }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "version" -> plugin.text().send(sender, plugin.text().message("version").replace("%version%", plugin.getDescription().getVersion()));
            case "reload" -> {
                plugin.reloadLocalConfigs(); plugin.reloadMessages();
                plugin.text().send(sender, plugin.text().message("reload"));
            }
            default -> { usage(sender, "/hexeconomy <reload|version>"); return true; }
        }
        return true;
    }

    private boolean openShop(CommandSender sender, boolean sell, String[] args) {
        if (!(sender instanceof Player player)) { plugin.text().send(sender, plugin.text().message("player-only")); return true; }
        if (sell && args.length == 1 && args[0].equalsIgnoreCase("all")) plugin.shopGui().confirmSellAll(player);
        else if (sell && args.length > 0) { usage(sender, "/sellgui [all]"); return true; }
        else if (!sell && args.length > 0) { usage(sender, "/shop"); return true; }
        else if (sell) plugin.shopGui().openSell(player); else plugin.shopGui().openRoot(player);
        return true;
    }

    private boolean auction(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) { plugin.text().send(sender, plugin.text().message("player-only")); return true; }
        if (args.length == 0) { plugin.auctionGui().open(player, null, null, "newest", 0); return true; }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "sell" -> {
                if (args.length != 2) { usage(sender, "/ah sell <price>"); return true; }
                double price = parseAmount(args[1]);
                if (!Double.isFinite(price) || price < plugin.getConfig().getDouble("auction.min-price", 0.01)
                        || price > plugin.getConfig().getDouble("auction.max-price", 100_000_000)) {
                    plugin.text().send(sender, plugin.text().message("invalid-amount")); return true;
                }
                ItemStack hand = player.getInventory().getItemInMainHand();
                if (hand.getType().isAir()) { plugin.text().send(sender, "&cHold the item you want to list."); return true; }
                int maximum = plugin.getConfig().getInt("auction.max-active-listings", 10);
                plugin.store().activeListingCount(player.getUniqueId()).whenComplete((count, countError) -> main(() -> {
                    if (countError != null) { report(sender, countError); return; }
                    if (count >= maximum) { plugin.text().send(sender, "&cYou have reached the active listing limit."); return; }
                    if (!player.isOnline() || player.getInventory().getItemInMainHand().isSimilar(hand) == false
                            || player.getInventory().getItemInMainHand().getAmount() != hand.getAmount()) {
                        plugin.text().send(sender, "&cYour held item changed. Try again."); return;
                    }
                    ItemStack listed = hand.clone();
                    double fee = price * plugin.getConfig().getDouble("auction.listing-fee-percent", 0) / 100.0;
                    long expiry = System.currentTimeMillis() + plugin.getConfig().getLong("auction.expiration-hours", 168) * 3_600_000L;
                    player.getInventory().setItemInMainHand(null);
                    plugin.store().createListing(player.getUniqueId(), player.getName(), listed.serializeAsBytes(),
                            listed.getType().name(), auctionCategory(listed.getType()), price, fee, expiry)
                            .whenComplete((id, error) -> main(() -> {
                                if (error != null || id == null || id < 0) {
                                    if (player.isOnline()) giveOrDrop(player, listed);
                                    else plugin.store().addItemClaim(player.getUniqueId(), listed.serializeAsBytes())
                                            .exceptionally(restoreError -> { plugin.getLogger().severe("Failed to restore auction item for " + player.getUniqueId()); return null; });
                                    plugin.text().send(sender, plugin.text().message(error == null ? "insufficient-funds" : "transaction-failed"));
                                } else {
                                    plugin.economy().invalidate(player.getUniqueId());
                                    plugin.text().send(sender, "&aListed " + listed.getAmount() + "x " + listed.getType().name()
                                            + " as #" + id + " for " + currency() + SqliteStore.money(price) + ".");
                                }
                            }));
                }));
            }
            case "search" -> {
                if (args.length < 2) { usage(sender, "/ah search <item>"); return true; }
                plugin.auctionGui().open(player, String.join(" ", Arrays.copyOfRange(args, 1, args.length)), null, "newest", 0);
            }
            case "category" -> {
                if (args.length != 2) { usage(sender, "/ah category <category>"); return true; }
                plugin.auctionGui().open(player, null, args[1], "newest", 0);
            }
            case "sort" -> {
                if (args.length != 2 || !Set.of("newest", "oldest", "price_asc", "price_desc").contains(args[1].toLowerCase(Locale.ROOT))) {
                    usage(sender, "/ah sort <newest|oldest|price_asc|price_desc>"); return true;
                }
                plugin.auctionGui().open(player, null, null, args[1].toLowerCase(Locale.ROOT), 0);
            }
            case "cancel" -> {
                if (args.length != 2) { usage(sender, "/ah cancel <listing-id>"); return true; }
                long id;
                try { id = Long.parseLong(args[1]); } catch (NumberFormatException ex) { plugin.text().send(sender, plugin.text().message("invalid-amount")); return true; }
                plugin.store().cancelListing(id, player.getUniqueId()).whenComplete((ok, error) -> main(() -> {
                    if (error != null) { report(sender, error); return; }
                    plugin.text().send(sender, Boolean.TRUE.equals(ok) ? "&aListing cancelled. Use /ah claim to collect its item."
                            : "&cThat active listing was not found or is not yours.");
                }));
            }
            case "remove" -> {
                if (!sender.hasPermission("hexa.ah.admin")) { noPermission(sender); return true; }
                if (args.length != 2) { usage(sender, "/ah remove <listing-id>"); return true; }
                long id;
                try { id = Long.parseLong(args[1]); } catch (NumberFormatException ex) { plugin.text().send(sender, plugin.text().message("invalid-amount")); return true; }
                plugin.store().adminRemoveListing(id).whenComplete((ok, error) -> main(() -> {
                    if (error != null) { report(sender, error); return; }
                    plugin.text().send(sender, Boolean.TRUE.equals(ok) ? "&aListing removed and returned to its seller's claims."
                            : "&cActive listing not found.");
                }));
            }
            case "expired" -> showClaims(player);
            case "claim" -> claimItems(player);
            default -> usage(sender, "/ah [sell|search|category|expired|claim|cancel|sort] ...");
        }
        return true;
    }

    private void showClaims(Player player) {
        plugin.store().claims(player.getUniqueId()).whenComplete((claims, error) -> main(() -> {
            if (error != null) { report(player, error); return; }
            plugin.text().send(player, claims.isEmpty() ? "&7No returned auction items are waiting."
                    : "&eYou have " + claims.size() + " returned or purchased item claim(s). Use /ah claim.");
        }));
    }

    private void claimItems(Player player) {
        plugin.store().claims(player.getUniqueId()).whenComplete((claims, error) -> main(() -> {
            if (error != null) { report(player, error); return; }
            if (claims.isEmpty()) { plugin.text().send(player, "&7You have no auction items to claim."); return; }
            for (SqliteStore.Claim claim : claims) {
                if (!"ITEM".equals(claim.kind()) || claim.item() == null) continue;
                ItemStack item;
                try { item = ItemStack.deserializeBytes(claim.item()); }
                catch (RuntimeException ex) { plugin.getLogger().warning("Invalid serialized auction claim #" + claim.id()); continue; }
                plugin.store().consumeClaim(claim.id(), player.getUniqueId()).whenComplete((consumed, consumeError) ->
                        main(() -> {
                            if (consumeError != null || !Boolean.TRUE.equals(consumed)) return;
                            if (player.isOnline()) {
                                giveOrDrop(player, item);
                                plugin.text().send(player, "&aClaimed an auction item.");
                            } else plugin.store().addItemClaim(player.getUniqueId(), item.serializeAsBytes())
                                    .exceptionally(restoreError -> { plugin.getLogger().severe("Failed to restore unclaimed item for " + player.getUniqueId()); return null; });
                        }));
            }
        }));
    }

    private String auctionCategory(Material material) {
        if (material.name().contains("LOG") || material.name().contains("WOOD")) return "LOGS";
        if (material.name().contains("ORE") || material.name().contains("RAW_")) return "ORES";
        if (material.name().contains("DIAMOND") || material.name().contains("EMERALD") || material.name().contains("INGOT")) return "MINERALS";
        if (material.name().contains("NETHER")) return "NETHER_ITEMS";
        if (material.name().contains("END_") || material.name().contains("ENDER")) return "END_ITEMS";
        if (material.name().contains("SWORD") || material.name().contains("AXE")) return "WEAPONS";
        return "MISCELLANEOUS";
    }

    private void giveOrDrop(Player player, ItemStack item) {
        Map<Integer, ItemStack> overflow = player.getInventory().addItem(item);
        overflow.values().forEach(extra -> player.getWorld().dropItemNaturally(player.getLocation(), extra));
    }

    private double parseAmount(String input) {
        try {
            BigDecimal value = new BigDecimal(input);
            if (value.scale() > 2 || value.signum() <= 0) return Double.NaN;
            double number = value.doubleValue();
            return Double.isFinite(number) ? number : Double.NaN;
        } catch (NumberFormatException e) { return Double.NaN; }
    }
    private String currency() { return plugin.getConfig().getString("economy.currency-symbol", "$"); }
    private void noPermission(CommandSender sender) { plugin.text().send(sender, plugin.text().message("no-permission")); }
    private void usage(CommandSender sender, String value) { plugin.text().send(sender, "&cUsage: " + value); }
    private void main(Runnable task) {
        if (Bukkit.isPrimaryThread()) task.run(); else Bukkit.getScheduler().runTask(plugin, task);
    }
    private void report(CommandSender sender, Throwable error) {
        Throwable cause = error instanceof CompletionException && error.getCause() != null ? error.getCause() : error;
        plugin.getLogger().warning("Database operation failed: " + cause.getMessage());
        plugin.text().send(sender, plugin.text().message("transaction-failed"));
    }

    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String root = command.getName().toLowerCase(Locale.ROOT);
        if (root.equals("eco") && args.length == 1) return starts(List.of("give", "take", "set", "reset"), args[0]);
        if (root.equals("hexeconomy") && args.length == 1) return starts(List.of("reload", "version"), args[0]);
        if (root.equals("pay") && args.length == 1) return starts(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[0]);
        if (root.equals("bal") && args.length == 1 && sender.hasPermission("hexa.balance.others"))
            return starts(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[0]);
        if (root.equals("eco") && args.length == 2) return starts(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
        return Collections.emptyList();
    }
    private List<String> starts(List<String> candidates, String prefix) {
        return candidates.stream().filter(s -> s.toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))).toList();
    }
}
