package com.hexamc.economy;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.util.*;

/** Inventory menus cancel every inventory mutation event before handling actions. */
final class ShopGui implements Listener {
    private final HexaEconomy plugin;
    private YamlConfiguration shop;
    private final Map<UUID, SaleDraft> sales = new HashMap<>();

    ShopGui(HexaEconomy plugin) { this.plugin = plugin; reload(); }
    void reload() { shop = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "shop.yml")); }

    void openRoot(Player player) {
        MenuHolder holder = new MenuHolder(Menu.CATEGORIES, null, 0);
        Inventory inv = Bukkit.createInventory(holder, 54, plugin.text().prefixed(plugin.getConfig().getString("gui.shop-title", "&8HexaMC Shop")));
        holder.inventory = inv;
        ConfigurationSection categories = shop.getConfigurationSection("categories");
        if (categories != null) {
            int slot = 0;
            for (String name : categories.getKeys(false)) {
                if (slot >= 45) break;
                Material icon = material(categories.getString(name + ".icon", "CHEST"), Material.CHEST);
                inv.setItem(slot++, button(icon, "&e" + name, List.of("&7Browse items in this category.")));
            }
        }
        if (plugin.getConfig().getBoolean("sell.sell-all-enabled", true))
            inv.setItem(48, button(Material.HOPPER, "&6Sell all eligible", List.of("&7Review the total before selling.")));
        inv.setItem(49, button(Material.BARRIER, "&cClose", List.of()));
        player.openInventory(inv);
    }

    void confirmSellAll(Player player) {
        if (!plugin.getConfig().getBoolean("sell.sell-all-enabled", true)) {
            plugin.text().send(player, "&cSell-all is disabled."); return;
        }
        Map<Material, Integer> counts = eligibleCounts(player);
        double total = counts.entrySet().stream().mapToDouble(e -> price(e.getKey(), true) * e.getValue()).sum();
        int count = counts.values().stream().mapToInt(Integer::intValue).sum();
        if (count == 0 || total <= 0) { plugin.text().send(player, "&cYou have no eligible items to sell."); return; }
        MenuHolder holder = new MenuHolder(Menu.SELL_ALL_CONFIRM, null, 0);
        Inventory inv = Bukkit.createInventory(holder, 27, plugin.text().prefixed("&8Confirm sell-all"));
        holder.inventory = inv;
        inv.setItem(4, button(Material.HOPPER, "&eSell " + count + " eligible items?",
                List.of("&7Items with protected/custom metadata are excluded.", "&7Total: &a" + currency() + SqliteStore.money(total))));
        inv.setItem(13, button(Material.LIME_CONCRETE, "&aConfirm sale", List.of("&eClick to sell all eligible items.")));
        inv.setItem(22, button(Material.BARRIER, "&cCancel", List.of()));
        player.openInventory(inv);
    }

    void openCategory(Player player, String category, int page) {
        MenuHolder holder = new MenuHolder(Menu.ITEMS, category, page);
        Inventory inv = Bukkit.createInventory(holder, 54,
                plugin.text().prefixed(plugin.getConfig().getString("gui.category-title", "&8Shop: %category%").replace("%category%", category)));
        holder.inventory = inv;
        List<String> keys = itemKeys(category, false);
        int start = Math.max(0, page) * 45;
        for (int i = 0; i < 45 && start + i < keys.size(); i++) {
            String key = keys.get(start + i);
            Material mat = material(key, Material.BARRIER);
            double buy = shop.getDouble("items." + key + ".buy", 0);
            double sell = shop.getDouble("items." + key + ".sell", 0);
            List<String> lore = new ArrayList<>();
            lore.add("&7Buy: &a" + currency() + SqliteStore.money(buy));
            lore.add("&7Sell: &e" + (shop.getBoolean("items." + key + ".sell-enabled") ? currency() + SqliteStore.money(sell) : "disabled"));
            lore.add("&8Click to view purchase options.");
            inv.setItem(i, button(mat, "&f" + shop.getString("items." + key + ".name", pretty(key)), lore));
        }
        if (page > 0) inv.setItem(45, button(Material.ARROW, "&ePrevious page", List.of()));
        inv.setItem(49, button(Material.BARRIER, "&cBack", List.of()));
        if (start + 45 < keys.size()) inv.setItem(53, button(Material.ARROW, "&eNext page", List.of()));
        player.openInventory(inv);
    }

    void openSell(Player player) {
        MenuHolder holder = new MenuHolder(Menu.SELL, null, 0);
        Inventory inv = Bukkit.createInventory(holder, 54, plugin.text().prefixed(plugin.getConfig().getString("gui.sell-title", "&8Sell Items")));
        holder.inventory = inv;
        Set<Material> shown = new LinkedHashSet<>();
        for (ItemStack stack : player.getInventory().getStorageContents()) {
            if (stack != null && !stack.getType().isAir() && isSellable(stack) && hasItem(stack.getType(), true))
                shown.add(stack.getType());
        }
        int slot = 0;
        for (Material material : shown) {
            if (slot >= 45) break;
            int count = countSellable(player, material);
            double price = price(material, true);
            inv.setItem(slot++, button(material, "&f" + pretty(material.name()), List.of(
                    "&7In inventory: &f" + count, "&7Sell price: &a" + currency() + SqliteStore.money(price) + " each",
                    "&eClick to review selling the stack.")));
        }
        inv.setItem(49, button(Material.BARRIER, "&cClose", List.of()));
        if (shown.isEmpty()) inv.setItem(22, button(Material.PAPER, "&7No eligible items found", List.of()));
        player.openInventory(inv);
    }

    private void confirmBuy(Player player, String key) {
        Material material = material(key, Material.BARRIER);
        double price = shop.getDouble("items." + key + ".buy", 0);
        MenuHolder holder = new MenuHolder(Menu.BUY_CONFIRM, key, 0);
        Inventory inv = Bukkit.createInventory(holder, 27, plugin.text().prefixed("&8Confirm purchase"));
        holder.inventory = inv;
        inv.setItem(4, button(material, "&f" + shop.getString("items." + key + ".name", pretty(key)),
                List.of("&7Unit price: &a" + currency() + SqliteStore.money(price), "&7Select quantity below.")));
        int[] sizes = {1, 16, 64};
        int[] slots = {11, 13, 15};
        for (int i = 0; i < sizes.length; i++) {
            int amount = Math.min(sizes[i], material.getMaxStackSize());
            inv.setItem(slots[i], button(material, "&aBuy " + amount, List.of("&7Total: &a" + currency()
                    + SqliteStore.money(price * amount), "&eClick to confirm.")));
        }
        inv.setItem(22, button(Material.BARRIER, "&cCancel", List.of()));
        player.openInventory(inv);
    }

    private void confirmSell(Player player, Material material) {
        int amount = countSellable(player, material);
        if (amount <= 0) { openSell(player); return; }
        SaleDraft draft = new SaleDraft(material, amount);
        sales.put(player.getUniqueId(), draft);
        MenuHolder holder = new MenuHolder(Menu.SELL_CONFIRM, material.name(), amount);
        Inventory inv = Bukkit.createInventory(holder, 27, plugin.text().prefixed("&8Confirm sale"));
        holder.inventory = inv;
        inv.setItem(4, button(material, "&f" + pretty(material.name()), List.of("&7Quantity: &f" + amount,
                "&7Total: &a" + currency() + SqliteStore.money(price(material, true) * amount))));
        inv.setItem(13, button(Material.LIME_CONCRETE, "&aSell all " + amount, List.of("&eClick to confirm.")));
        inv.setItem(22, button(Material.BARRIER, "&cCancel", List.of()));
        player.openInventory(inv);
    }

    @EventHandler public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder(false) instanceof MenuHolder holder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getView().getTopInventory() || event.getClick().isShiftClick()
                || event.getClick() == ClickType.DOUBLE_CLICK || event.getClick() == ClickType.NUMBER_KEY) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;
        int slot = event.getRawSlot();
        if (slot < 0 || slot >= holder.inventory.getSize()) return;
        if (holder.menu == Menu.CATEGORIES) {
            if (slot == 49) { player.closeInventory(); return; }
            ConfigurationSection categories = shop.getConfigurationSection("categories");
            if (categories == null) return;
            int index = 0;
            for (String category : categories.getKeys(false)) {
                if (index++ == slot) { openCategory(player, category, 0); return; }
            }
        } else if (holder.menu == Menu.ITEMS) {
            if (slot == 49) { openRoot(player); return; }
            if (slot == 45) { openCategory(player, holder.key, Math.max(0, holder.page - 1)); return; }
            if (slot == 53) { openCategory(player, holder.key, holder.page + 1); return; }
            List<String> keys = itemKeys(holder.key, false);
            int index = holder.page * 45 + slot;
            if (slot < 45 && index < keys.size()) confirmBuy(player, keys.get(index));
        } else if (holder.menu == Menu.SELL) {
            if (slot == 49) { player.closeInventory(); return; }
            if (slot == 48 && plugin.getConfig().getBoolean("sell.sell-all-enabled", true)) { confirmSellAll(player); return; }
            ItemStack clicked = holder.inventory.getItem(slot);
            if (clicked != null && hasItem(clicked.getType(), true)) confirmSell(player, clicked.getType());
        } else if (holder.menu == Menu.BUY_CONFIRM) {
            if (slot == 22) { openCategory(player, category(holder.key), 0); return; }
            int amount = slot == 11 ? 1 : slot == 13 ? Math.min(16, material(holder.key, Material.STONE).getMaxStackSize())
                    : slot == 15 ? material(holder.key, Material.STONE).getMaxStackSize() : 0;
            if (amount > 0) buy(player, holder.key, amount);
        } else if (holder.menu == Menu.SELL_CONFIRM) {
            if (slot == 22) { sales.remove(player.getUniqueId()); openSell(player); return; }
            if (slot == 13) sell(player, holder.key, holder.page);
        } else if (holder.menu == Menu.SELL_ALL_CONFIRM) {
            if (slot == 22) { openSell(player); return; }
            if (slot == 13) sellAll(player);
        }
    }

    @EventHandler public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder(false) instanceof MenuHolder) event.setCancelled(true);
    }

    private void buy(Player player, String key, int amount) {
        Material material = material(key, Material.BARRIER);
        if (material.isAir() || !shop.getBoolean("items." + key + ".buy-enabled", false)) return;
        double total = price(material, false) * amount;
        if (!Double.isFinite(total) || total <= 0) { plugin.text().send(player, plugin.text().message("invalid-amount")); return; }
        ItemStack product = new ItemStack(material, amount);
        if (player.getInventory().firstEmpty() < 0 && !canStack(player, product)) {
            plugin.text().send(player, "&cYour inventory is full."); return;
        }
        String name = player.getName();
        plugin.store().change(player.getUniqueId(), name, total, "TAKE").whenComplete((ok, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) {
                plugin.store().change(player.getUniqueId(), name, total, "GIVE");
                return;
            }
            if (error != null || !Boolean.TRUE.equals(ok)) {
                plugin.text().send(player, plugin.text().message(error == null ? "insufficient-funds" : "transaction-failed")); return;
            }
            Map<Integer, ItemStack> overflow = player.getInventory().addItem(product);
            if (!overflow.isEmpty()) {
                plugin.store().change(player.getUniqueId(), name, total, "GIVE");
                plugin.text().send(player, "&cPurchase cancelled because your inventory became full.");
            } else {
                plugin.economy().invalidate(player.getUniqueId());
                plugin.text().send(player, "&aPurchased " + amount + "x " + pretty(key) + " for " + currency() + SqliteStore.money(total) + ".");
            }
        }));
    }

    private void sell(Player player, String materialName, int requested) {
        Material material = material(materialName, Material.AIR);
        int amount = Math.min(requested, countSellable(player, material));
        if (amount <= 0 || !hasItem(material, true)) { plugin.text().send(player, "&cNo eligible items to sell."); return; }
        double total = price(material, true) * amount;
        if (!Double.isFinite(total) || total <= 0) { plugin.text().send(player, plugin.text().message("transaction-failed")); return; }
        int removed = removeSellable(player, material, amount);
        if (removed != amount) {
            player.getInventory().addItem(new ItemStack(material, removed));
            plugin.text().send(player, plugin.text().message("transaction-failed")); return;
        }
        plugin.store().change(player.getUniqueId(), player.getName(), total, "GIVE").whenComplete((ok, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (error != null || !Boolean.TRUE.equals(ok)) {
                restoreItems(player, List.of(new ItemStack(material, amount)));
                return;
            }
            plugin.economy().invalidate(player.getUniqueId());
            if (player.isOnline()) plugin.text().send(player, "&aSold " + amount + "x " + pretty(material.name())
                    + " for " + currency() + SqliteStore.money(total) + ".");
        }));
        sales.remove(player.getUniqueId());
    }

    private void sellAll(Player player) {
        Map<Material, Integer> counts = eligibleCounts(player);
        List<ItemStack> removedItems = new ArrayList<>();
        double total = 0;
        for (ItemStack item : player.getInventory().getStorageContents()) {
            if (item == null || !isSellable(item)) continue;
            removedItems.add(item.clone());
        }
        for (Map.Entry<Material, Integer> entry : counts.entrySet()) total += price(entry.getKey(), true) * entry.getValue();
        if (removedItems.isEmpty() || total <= 0) { plugin.text().send(player, "&cYou have no eligible items to sell."); return; }
        for (Map.Entry<Material, Integer> entry : counts.entrySet()) {
            int removed = removeSellable(player, entry.getKey(), entry.getValue());
            if (removed != entry.getValue()) {
                restoreItems(player, removedItems);
                plugin.text().send(player, plugin.text().message("transaction-failed")); return;
            }
        }
        double amount = total;
        plugin.store().change(player.getUniqueId(), player.getName(), amount, "GIVE").whenComplete((ok, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (error != null || !Boolean.TRUE.equals(ok)) {
                        restoreItems(player, removedItems);
                        if (player.isOnline()) plugin.text().send(player, plugin.text().message("transaction-failed"));
                        return;
                    }
                    plugin.economy().invalidate(player.getUniqueId());
                    if (player.isOnline()) plugin.text().send(player, "&aSold all eligible items for " + currency() + SqliteStore.money(amount) + ".");
                }));
    }

    private Map<Material, Integer> eligibleCounts(Player player) {
        Map<Material, Integer> counts = new LinkedHashMap<>();
        for (ItemStack item : player.getInventory().getStorageContents())
            if (item != null && isSellable(item)) counts.merge(item.getType(), item.getAmount(), Integer::sum);
        return counts;
    }

    private void restoreItems(Player player, List<ItemStack> items) {
        if (player.isOnline()) items.forEach(item -> giveOrDrop(player, item));
        else for (ItemStack item : items) plugin.store().addItemClaim(player.getUniqueId(), item.serializeAsBytes())
                .exceptionally(error -> { plugin.getLogger().severe("Could not restore removed item to claim " + player.getUniqueId()); return null; });
    }

    private int removeSellable(Player player, Material material, int amount) {
        int left = amount;
        for (int i = 0; i < player.getInventory().getStorageContents().length && left > 0; i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (stack == null || stack.getType() != material || !isSellable(stack)) continue;
            int take = Math.min(left, stack.getAmount());
            left -= take;
            if (take == stack.getAmount()) player.getInventory().setItem(i, null); else stack.setAmount(stack.getAmount() - take);
        }
        return amount - left;
    }
    private int countSellable(Player player, Material mat) {
        int total = 0;
        for (ItemStack item : player.getInventory().getStorageContents())
            if (item != null && item.getType() == mat && isSellable(item)) total += item.getAmount();
        return total;
    }
    private void giveOrDrop(Player player, ItemStack stack) {
        Map<Integer, ItemStack> extra = player.getInventory().addItem(stack);
        extra.values().forEach(i -> player.getWorld().dropItemNaturally(player.getLocation(), i));
    }
    private boolean canStack(Player player, ItemStack product) {
        for (ItemStack item : player.getInventory().getStorageContents())
            if (item != null && item.isSimilar(product) && item.getAmount() + product.getAmount() <= item.getMaxStackSize()) return true;
        return false;
    }
    private boolean isSellable(ItemStack item) {
        if (!shop.getBoolean("items." + item.getType().name() + ".sell-enabled", false)) return false;
        if (plugin.getConfig().getStringList("sell.blacklist").contains(item.getType().name())) return false;
        if (!plugin.getConfig().getBoolean("sell.protect-custom-items", true) || !item.hasItemMeta()) return true;
        ItemMeta meta = item.getItemMeta();
        return !meta.hasDisplayName() && !meta.hasLore() && meta.getEnchants().isEmpty()
                && meta.getPersistentDataContainer().isEmpty();
    }
    private List<String> itemKeys(String category, boolean sell) {
        ConfigurationSection items = shop.getConfigurationSection("items");
        if (items == null) return List.of();
        List<String> out = new ArrayList<>();
        for (String key : items.getKeys(false)) {
            String path = "items." + key;
            if (shop.getString(path + ".category", "").equalsIgnoreCase(category)
                    && shop.getBoolean(path + (sell ? ".sell-enabled" : ".buy-enabled"), false)
                    && material(key, Material.AIR) != Material.AIR) out.add(key);
        }
        return out;
    }
    private boolean hasItem(Material material, boolean sell) {
        String path = "items." + material.name();
        return shop.contains(path) && shop.getBoolean(path + (sell ? ".sell-enabled" : ".buy-enabled"), false);
    }
    private double price(Material material, boolean sell) { return shop.getDouble("items." + material.name() + (sell ? ".sell" : ".buy"), 0); }
    private String category(String key) { return shop.getString("items." + key + ".category", "Miscellaneous"); }
    private String currency() { return plugin.getConfig().getString("economy.currency-symbol", "$"); }
    private Material material(String key, Material fallback) {
        Material result = key == null ? null : Material.matchMaterial(key);
        return result == null ? fallback : result;
    }
    private String pretty(String key) {
        StringBuilder result = new StringBuilder();
        for (String word : key.toLowerCase(Locale.ROOT).replace('_', ' ').split(" ")) {
            if (word.isEmpty()) continue;
            if (!result.isEmpty()) result.append(' ');
            result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return result.toString();
    }
    private ItemStack button(Material material, String title, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(plugin.text().prefixed(title));
        if (!lore.isEmpty()) meta.lore(lore.stream().map(plugin.text()::parse).toList());
        item.setItemMeta(meta);
        return item;
    }

    private enum Menu { CATEGORIES, ITEMS, SELL, BUY_CONFIRM, SELL_CONFIRM, SELL_ALL_CONFIRM }
    private static final class MenuHolder implements InventoryHolder {
        final Menu menu;
        final String key;
        final int page;
        Inventory inventory;
        MenuHolder(Menu menu, String key, int page) { this.menu = menu; this.key = key; this.page = page; }
        @Override public Inventory getInventory() { return inventory; }
    }
    private record SaleDraft(Material material, int amount) {}
}
