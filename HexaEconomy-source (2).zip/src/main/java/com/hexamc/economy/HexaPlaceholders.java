package com.hexamc.economy;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Locale;

/** Optional PlaceholderAPI placeholders; balances are served from the Vault cache. */
final class HexaPlaceholders extends PlaceholderExpansion {
    private final HexaEconomy plugin;
    HexaPlaceholders(HexaEconomy plugin) { this.plugin = plugin; }
    @Override public @NotNull String getIdentifier() { return "hexeconomy"; }
    @Override public @NotNull String getAuthor() { return "HexaMC"; }
    @Override public @NotNull String getVersion() { return plugin.getDescription().getVersion(); }
    @Override public boolean persist() { return true; }
    @Override public @Nullable String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return "";
        String key = params.toLowerCase(Locale.ROOT);
        if (key.equals("balance")) return SqliteStore.money(plugin.economy().getBalance(player));
        if (key.equals("formatted_balance")) return plugin.getConfig().getString("economy.currency-symbol", "$")
                + SqliteStore.money(plugin.economy().getBalance(player));
        return null;
    }
}
