package com.hexamc.economy;

import net.milkbowl.vault.economy.AbstractEconomy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Vault adapter backed by the same UUID accounts used by HexaEconomy commands. */
public final class EconomyProvider extends AbstractEconomy {
    private final HexaEconomy plugin;
    private final Map<UUID, Double> cache = new ConcurrentHashMap<>();
    EconomyProvider(HexaEconomy plugin) { this.plugin = plugin; }
    void cache(UUID id, double balance) { cache.put(id, balance); }
    void invalidate(UUID id) { cache.remove(id); }

    private String name(OfflinePlayer p) {
        return Objects.requireNonNullElse(p.getName(), p.getUniqueId().toString());
    }
    private double current(OfflinePlayer p) {
        Double value = cache.get(p.getUniqueId());
        if (value == null && plugin.isReady()) plugin.balance(p.getUniqueId(), name(p));
        return value == null ? 0 : value;
    }
    private EconomyResponse change(OfflinePlayer p, double amount, boolean deposit) {
        if (!plugin.isReady()) return failure(0, 0, EconomyResponse.ResponseType.FAILURE, "database_not_ready");
        if (!Double.isFinite(amount) || amount <= 0) return failure(amount, current(p), EconomyResponse.ResponseType.FAILURE, "invalid_amount");
        synchronized (cache) {
            double old = current(p), next = deposit ? old + amount : old - amount;
            if (!Double.isFinite(next) || next < -1e-9) return failure(amount, old, EconomyResponse.ResponseType.FAILURE, "insufficient_funds");
            next = Math.max(0, next);
            cache.put(p.getUniqueId(), next);
            plugin.store().change(p.getUniqueId(), name(p), amount, deposit ? "GIVE" : "TAKE")
                    .whenComplete((ok, error) -> {
                        if (error != null || !Boolean.TRUE.equals(ok)) {
                            plugin.getLogger().warning("Vault balance operation failed for " + p.getUniqueId());
                            plugin.balance(p.getUniqueId(), name(p)).exceptionally(loadError -> null);
                        } else plugin.balance(p.getUniqueId(), name(p)).exceptionally(loadError -> null);
                    });
            return new EconomyResponse(amount, next, EconomyResponse.ResponseType.SUCCESS, null);
        }
    }
    private EconomyResponse failure(double amount, double balance, EconomyResponse.ResponseType type, String error) {
        return new EconomyResponse(amount, balance, type, error);
    }

    @Override public boolean isEnabled() { return plugin.isEnabled() && plugin.isReady(); }
    @Override public String getName() { return "HexaEconomy"; }
    @Override public boolean hasBankSupport() { return false; }
    @Override public int fractionalDigits() { return 2; }
    @Override public String format(double amount) { return plugin.getConfig().getString("economy.currency-symbol", "$") + SqliteStore.money(amount); }
    @Override public String currencyNamePlural() { return plugin.getConfig().getString("economy.currency-name-plural", "coins"); }
    @Override public String currencyNameSingular() { return plugin.getConfig().getString("economy.currency-name-singular", "coin"); }
    @Override public boolean hasAccount(String playerName) { return Bukkit.getOfflinePlayer(playerName).hasPlayedBefore(); }
    @Override public boolean hasAccount(String playerName, String worldName) { return hasAccount(playerName); }
    @Override public boolean hasAccount(OfflinePlayer player) { return cache.containsKey(player.getUniqueId()); }
    @Override public double getBalance(String playerName) { return getBalance(Bukkit.getOfflinePlayer(playerName)); }
    @Override public double getBalance(String playerName, String worldName) { return getBalance(playerName); }
    @Override public double getBalance(OfflinePlayer player) { return current(player); }
    @Override public boolean has(String playerName, double amount) { return getBalance(playerName) >= amount; }
    @Override public boolean has(String playerName, String worldName, double amount) { return has(playerName, amount); }
    @Override public boolean has(OfflinePlayer player, double amount) { return getBalance(player) >= amount; }
    @Override public EconomyResponse withdrawPlayer(String playerName, double amount) { return withdrawPlayer(Bukkit.getOfflinePlayer(playerName), amount); }
    @Override public EconomyResponse withdrawPlayer(String playerName, String worldName, double amount) { return withdrawPlayer(playerName, amount); }
    @Override public EconomyResponse withdrawPlayer(OfflinePlayer player, double amount) { return change(player, amount, false); }
    @Override public EconomyResponse depositPlayer(String playerName, double amount) { return depositPlayer(Bukkit.getOfflinePlayer(playerName), amount); }
    @Override public EconomyResponse depositPlayer(String playerName, String worldName, double amount) { return depositPlayer(playerName, amount); }
    @Override public EconomyResponse depositPlayer(OfflinePlayer player, double amount) { return change(player, amount, true); }
    @Override public boolean createPlayerAccount(String playerName) { return createPlayerAccount(Bukkit.getOfflinePlayer(playerName)); }
    @Override public boolean createPlayerAccount(String playerName, String worldName) { return createPlayerAccount(playerName); }
    @Override public boolean createPlayerAccount(OfflinePlayer player) {
        if (!plugin.isReady()) return false;
        plugin.balance(player.getUniqueId(), name(player));
        return true;
    }
    @Override public List<String> getBanks() { return Collections.emptyList(); }
    @Override public EconomyResponse createBank(String name, String player) { return failure(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "banks_unsupported"); }
    @Override public EconomyResponse createBank(String name, OfflinePlayer player) { return failure(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "banks_unsupported"); }
    @Override public EconomyResponse deleteBank(String name) { return failure(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "banks_unsupported"); }
    @Override public EconomyResponse bankBalance(String name) { return failure(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "banks_unsupported"); }
    @Override public EconomyResponse bankHas(String name, double amount) { return failure(amount, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "banks_unsupported"); }
    @Override public EconomyResponse bankWithdraw(String name, double amount) { return failure(amount, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "banks_unsupported"); }
    @Override public EconomyResponse bankDeposit(String name, double amount) { return failure(amount, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "banks_unsupported"); }
    @Override public EconomyResponse isBankOwner(String name, String playerName) { return failure(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "banks_unsupported"); }
    @Override public EconomyResponse isBankOwner(String name, OfflinePlayer player) { return failure(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "banks_unsupported"); }
    @Override public EconomyResponse isBankMember(String name, String playerName) { return failure(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "banks_unsupported"); }
    @Override public EconomyResponse isBankMember(String name, OfflinePlayer player) { return failure(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "banks_unsupported"); }
}
