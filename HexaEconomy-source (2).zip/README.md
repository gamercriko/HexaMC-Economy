# HexaEconomy

Maven source for a Paper 26.2 / Java 25 economy plugin. SQLite is the persistent store; Vault uses the same UUID-based account records. Build with:

```sh
mvn clean package
```

The output is `target/HexaEconomy.jar`. Paper API, VaultAPI and PlaceholderAPI are provided dependencies; SQLite JDBC is shaded into the plugin. The published Paper API dependency currently targets `26.2.build.117-stable`.

## Install on Drexhost

1. Make a full server backup and stop the server.
2. Confirm the server runs Paper 26.2 with Java 25. Do not use a 1.21.x server with this build.
3. Upload `target/HexaEconomy.jar` into the server's `plugins/` directory.
4. Install Vault into `plugins/`. Install PlaceholderAPI if you want `%hexeconomy_balance%` and `%hexeconomy_formatted_balance%`. LuckPerms, Geyser and Floodgate can remain installed; they are optional dependencies.
5. Start the server once to generate `plugins/HexaEconomy/config.yml`, `shop.yml`, `messages.yml` and `economy.db`. Stop the server before editing YAML; start it again after changes.
6. The plugin stores its SQLite database under `plugins/HexaEconomy/economy.db`. Never delete that file to troubleshoot or upgrade. Take a server backup before replacing plugin files or changing versions.
7. Verify `/plugins`, run `/hexeconomy version`, then check `/bal`, `/shop`, `/sellgui`, and `/ah`.

Vault setup: Vault is a bridge, not a separate economy. On startup, HexaEconomy registers itself as Vault's Economy provider. If another plugin also registers an economy provider, adjust its provider priority or disable that competing economy; do not run two active economy plugins.

## LuckPerms examples

```text
/lp group default permission set hexa.shop true
/lp group default permission set hexa.sell true
/lp group default permission set hexa.ah true
/lp group default permission set hexa.pay true
/lp group default permission set hexa.balance true
/lp group default permission set hexa.baltop true
/lp group staff permission set hexa.balance.others true
/lp group admin permission set hexa.eco true
/lp group admin permission set hexa.admin true
/lp group admin permission set hexa.ah.admin true
```

Permission nodes are listed in `src/main/resources/plugin.yml`. Configure `shop.yml` prices and categories without recompiling. The example prices in that file are **provisional**, not FireMC prices.

## Public FireMC pricing research

The public FireMC storefront exposes real-money coin bundles and rank subscriptions. It does not publish verifiable in-game Minecraft item buy/sell prices on the pages found, so this plugin does not label any example economy values as exact FireMC prices. See [FireMC's public coin category](https://store.firemc.fun/category/coins).

## Implemented in this source snapshot

- Gradient RGB prefix parser preserving bold, italic and underline; prefixed command output and GUI titles.
- SQLite UUID accounts, prepared statements, transaction log rows, atomic SQL transfers, starting balances and asynchronous JDBC work.
- `/bal`, `/balance`, `/pay`, `/eco`, `/baltop`, `/hexeconomy reload|version`.
- Configured shop categories and item buy/sell prices; buy quantity confirmation; protected sell GUI; optional sell-all confirmation; item blacklist and custom metadata safeguards.
- Auction listing persistence, active-listing limits, fees, expiration, search, category/sort query, purchase confirmation, cancel, admin removal, purchase/cancel/expiry item claims, and atomic listing purchase settlement.
- Vault Economy provider and basic PlaceholderAPI balance placeholders.
- Protected shop and auction inventories cancel click/drag mutations.

## Known gaps — not production-ready yet

This source snapshot is **not a finished or live-server-verified production release**. The conversation could not be moved to a Replit Project because the account's Project limit was reached, and this workspace only has Java 19. Dependency resolution succeeds, but `mvn package` stops at `release version 25 not supported`; no JAR has been produced and Java compilation has not been verified.

- Baltop is currently a paginated text command, not a heads/ranks GUI; LuckPerms ranks are not displayed. PlaceholderAPI currently exposes only balance placeholders.
- The auction GUI supports listing review and purchase confirmation, but its category filter matches stored material-category keys; it does not provide the full requested player-head/category-browser experience.
- There is no configurable per-item permission enforcement in the shop, and the example `shop.yml` is a starter catalogue rather than every Minecraft item.
- A SQLite snapshot is created at plugin startup in `plugins/HexaEconomy/backups/`; retain separate off-server backups before upgrades and do not delete the live database.
- Vault's synchronous API has to answer from an in-memory cache; new/offline accounts may initially return a cache miss before the asynchronous database load completes. Its methods queue persistence asynchronously, so the synchronous Vault response is not a disk-commit acknowledgment.
- Claims use a database record to avoid direct item delivery from the auction settlement transaction. Inventory delivery and SQLite cannot be committed as one atomic operation; do not describe this as exactly-once delivery.
- Geyser/Floodgate compatibility is through ordinary Bukkit commands and inventories; no Bedrock-specific UX has been tested.

## Pre-production test checklist

Run these on a disposable Paper 26.2 server with Vault, LuckPerms, PlaceholderAPI, Geyser and Floodgate versions you plan to use:

1. Start/restart with an existing `economy.db`; confirm balances and active listings persist and no database file is removed.
2. Test `/pay` for normal, insufficient, invalid, maximum, self, offline-recipient and near-simultaneous transfers; check both balances and transaction rows.
3. Test Vault deposit/withdraw calls from another plugin and compare `/bal` and the other plugin's balance view.
4. Test every shop purchase quantity, full inventory, disconnect during pending transaction, sell protection, blacklist and sell-all toggle.
5. Create, buy, cancel, expire and admin-remove auctions concurrently from two clients; check listing status, balances and `/ah claim`.
6. Test GUI shift-click, drag, number-key, offhand swap, double-click, creative click and disconnect/relog behavior.
7. Test all permissions with default/staff/admin groups and Java + Bedrock accounts.
8. Only after those pass, test a production-like backup/restore and upgrade using a copy of the live database.
